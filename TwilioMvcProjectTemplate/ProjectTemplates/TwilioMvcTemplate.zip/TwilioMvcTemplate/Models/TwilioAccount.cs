namespace $projectname$.Models
{
   public class TwilioAccount
    {
        public string AccountSid { get; set; }
        public string AuthToken { get; set; }
    }
}